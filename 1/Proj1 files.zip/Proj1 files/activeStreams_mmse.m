function [ Ptx ] = activeStreams_mmse( phi )
% function [ Ptx ] = activeStreams_mmse( phi )
%
% Function computes the power values for which the MMSE power
% allocation switches from K to K+1 active streams
%
% Input:
% phi: vector of eigenmode coefficients phi1,...,phiN
% Output:
% Ptx: vector of power values (size N-1x1) for which the power allocation
% switches from K to K+1 active streams

% TODO

end

