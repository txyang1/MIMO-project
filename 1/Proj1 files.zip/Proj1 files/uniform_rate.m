function [psi,K] = uniform_rate(phi,Ptx)
%
% Rate maximizing uniform power allocation for the given average
% total transmit power constraint sum(psi)<=Ptx.
%
% Inputs
% phi: vector of eigenmode coefficients phi1,...,phiN
% Ptx: available sum transmit power Ptx
% Outputs
% psi: vector of optimal power allocations psi1,...,psiN
% K: number of active data streams K

phi = phi(:);

% TODO