% Script           rate_visualization
%***************************************************************
%
% Visualization of the achievable rates of the considered four
% power allocation strategies for a point-to-point MIMO system.
% Plots the achievable rates versus the transmit power Ptx in dB.
%
%***************************************************************

% System Parameters
N = 4;
Ptx_dB = -20:0.1:30;
no_Ptx = length(Ptx_dB);

% Transmit power calculation
Ptx = % TODO

% Channel and eigenmode coefficients
load('example_channels.mat','H','Cn');
phi = % TODO

% Initialization of rate arrays
R_waterfilling = zeros(1,no_Ptx);
R_uniform         = zeros(1,no_Ptx);
R_mmse         = zeros(1,no_Ptx);
R_tf_mmse      = zeros(1,no_Ptx);

% Calculation of the achievable rates
% TODO

% Calculation of the the transmit powers (in dB) where the number of streams switches from K to K+1
% TODO

% Calculation of the corresponding rates to the switching powers from K to K+1
% TODO

% Plotting the achievable rates over Ptx in dB
rate_figure = figure;
hold on;
plot(Ptx_dB,R_waterfilling,'Color','k','LineStyle','-','Marker','none','LineWidth',2);
plot(Ptx_dB,R_mmse,'Color','r','LineStyle','-','Marker','none','LineWidth',2);
plot(Ptx_dB,R_uniform,'Color','m','LineStyle','-','Marker','none','LineWidth',2);
plot(Ptx_dB,R_tf_mmse,'Color','b','LineStyle','-','Marker','none','LineWidth',2);
hold off;

% Changing the visualization of the plot
xlabel('Ptx in [dB]');
ylabel('rate in [bits/channel usage]');
legend(gca,'waterfilling','MMSE allocation','uniform','TF-MMSE allocation','Location','NorthWest');
grid on;

% Marking the switching points in the plots in the form
% plot(VALUES,VALUES,'Color',COLOR,'LineStyle','none','Marker',MARKER,'LineWidth',2);
% Use the same values for COLOR as are used for plotting the lines.
% Use the following values for MARKER: 
%        'o' for waterfilling
%        's' for MMSE
hold on;
% TODO
hold off;
