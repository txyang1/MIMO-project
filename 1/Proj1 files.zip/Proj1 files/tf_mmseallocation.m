function [ R, MSE ] = tf_mmseallocation( H, Ptx )
%
% MSE optimal power allocation with transmit filter design.
%
% Inputs
% H: Transmission Channel
% Ptx: available sum transmit power Ptx
% Outputs
% R: Achievable rate
% MSE: Achievable MSE



% TODO

