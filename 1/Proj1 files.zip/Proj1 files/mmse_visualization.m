% Script           mmse_visualization
%***************************************************************
%
% Visualization of the achievable MMSE of the considered four
% power allocation strategies for a point-to-point MIMO system.
% Plots the achievable MMSE versus the transmit power Etx in dB.
%
%***************************************************************

% System Parameters
N = 4;
Ptx_dB = -20:0.1:30;
no_Ptx = length(Ptx_dB);

% Transmit power calculation
Ptx = % TODO

% Channel and eigenmode coefficients
load('example_channels.mat','H','Cn');
phi = % TODO

% Initialization of MMSE arrays
MMSE_waterfilling = zeros(1,no_Ptx);
MMSE_mmse         = zeros(1,no_Ptx);
MMSE_uniform      = zeros(1,no_Ptx);
MMSE_zf_mmse      = zeros(1,no_Ptx);

% Calculation of the achievable MMSEs
% TODO

% Calculation of the the transmit powers (in dB) where the number of streams switches from K to K+1
% TODO

% Calculation of the corresponding MMSEs to the switching powers from K to K+1
% TODO

% Plotting the achievable MMSEs over Etx in dB in a semilogarithmic scale
mmse_figure = figure;
hold on;
semilogy(Ptx_dB,MMSE_waterfilling,'Color','k','LineStyle','-','Marker','none','LineWidth',2);
semilogy(Ptx_dB,MMSE_mmse,'Color','r','LineStyle','-','Marker','none','LineWidth',2);
semilogy(Ptx_dB,MMSE_uniform,'Color','m','LineStyle','-','Marker','none','LineWidth',2);
semilogy(Ptx_dB,MMSE_tf_mmse,'Color','b','LineStyle','-','Marker','none','LineWidth',2);
hold off;

% Change visualization of the plot
xlabel('Etx in [dB]');
ylabel('mean square error');
legend(gca,'waterfilling','MMSE allocation','uniform','TF-MMSE allocation','Location','NorthWest');
grid on;

% Marking the switching points in the plots in the form
% semilogy(VALUES,VALUES,'Color',COLOR,'LineStyle','none','Marker',MARKER,'LineWidth',2);
% Use the same values for COLOR as are used for plotting the lines.
% Use the following values for MARKER: 
%        'o' for waterfilling
%        's' for mmse
hold on;
% TODO
hold off;

