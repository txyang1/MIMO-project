function [S] = MACtoBCtransform(Q,H,order)
% Function [S] = MACtoBCtransform(Q,H,order)
% 
% Rate based duality transformation from the
% multiple access channel to the broadcast channel.
%
% Inputs
% Q: K x 1 cell array with matrix Qk per cell
% H: M x N cell array with channel Hk per cell
% order: 1 x K vector with BC encoding order
% Output
% S: K x 1 cell array of covariance matrix Sk per cell

% parameters
[M,N] = size(H{1});
K = length(H);

% initialization
S = cell(K,1);

