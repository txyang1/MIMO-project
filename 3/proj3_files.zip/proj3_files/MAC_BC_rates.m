function [ R_BC, R_MAC ] = MAC_BC_rates( H, Q, S, order )
% function [ R_BC, R_MAC ] = MAC_BC_rates( H, Q, S, order )
%
% The function calculates the achievable rates of the MAC and
% BC for given channels Hk and transmit covariance matrices Qk and Sk and
% a given decoding and encoding order.
%
% Input Specifications:
% H: Kx1 cell array with channel Hk per cell
% Q: Kx1 cell array with MxM matrix Qk per cell
% S: Kx1 cell array with NxN matrix Sk per cell
% order: 1xK vector in {1,...,K} with the BC encoding order
%
% Output Specifications:
% R_BC:  Kx1 array with achievable rates of the BC
% R_MAC: Kx1 array with achievable rates of the MAC

[M,N] = size(H{1});
K = length(H);

R_BC = zeros(K,1);
R_MAC = zeros(K,1);

end







